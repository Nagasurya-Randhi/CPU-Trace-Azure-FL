# config.py
NUM_CLIENTS = 5
EPOCHS = 1
WINDOW_SIZE = 10
UNITS = 64
SERVER_ADDRESS = "localhost:8080"
DATA_DIR = "../help"
